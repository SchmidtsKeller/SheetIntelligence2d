/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useCallback, useEffect, useRef, useState } from 'react';
import { Download } from 'lucide-react';
import {
  AnyClipId,
  CharacterId,
  InterpolationMode,
  getCharacterClipOrder,
} from './engine/keyframes';
import { LightingMode } from './engine/groundWorld';
import type { GodotBakeTarget } from './engine/godotExport';
import {
  GsmCanvasStage,
  LiveTelemetry,
  LocomotionMode,
} from './components/GsmCanvasStage';
import { AnimationTimelineBar } from './components/AnimationTimelineBar';
import { RigInspectorDrawer } from './components/RigInspectorDrawer';
import { GodotExportModal } from './components/GodotExportModal';

function mapClipBetweenCharacters(
  currentClip: AnyClipId,
  nextCharacter: CharacterId
): AnyClipId {
  if (nextCharacter === 'sheep') {
    if (currentClip === 'stalk') return 'graze';
    if (currentClip === 'lunge') return 'sprint';
    if (currentClip === 'idle' || currentClip === 'walk') return currentClip;
    return 'walk';
  }
  if (currentClip === 'graze') return 'stalk';
  if (currentClip === 'sprint') return 'lunge';
  if (currentClip === 'idle' || currentClip === 'walk') return currentClip;
  return 'walk';
}

export default function App() {
  const [character, setCharacter] = useState<CharacterId>('gsm');
  const [clipId, setClipId] = useState<AnyClipId>('walk');
  const [interpMode, setInterpMode] = useState<InterpolationMode>('hermite');
  const [locomotionMode, setLocomotionMode] = useState<LocomotionMode>('treadmill');
  const [lightingMode, setLightingMode] = useState<LightingMode>('tenebrism');
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [speedMultiplier, setSpeedMultiplier] = useState<number>(1.0);
  const [creatureScale, setCreatureScale] = useState<number>(0.84);
  const [showRigOverlay, setShowRigOverlay] = useState<boolean>(false);
  const [scrubPhase, setScrubPhase] = useState<number | null>(null);
  const [stepNonce, setStepNonce] = useState<number>(0);

  const [inspectorOpen, setInspectorOpen] = useState<boolean>(() =>
    typeof window !== 'undefined' ? window.innerWidth >= 1024 : true
  );
  const [exportModalOpen, setExportModalOpen] = useState<boolean>(false);
  const [rigTarget, setRigTarget] = useState<GodotBakeTarget | null>(null);

  const [telemetry, setTelemetry] = useState<LiveTelemetry>({
    phase: 0,
    speedPx: 300,
    groundedCount: 12,
    liftedCount: 8,
    totalLegs: 20,
    activeTransition: null,
  });

  const playheadRef = useRef<HTMLInputElement | null>(null);
  const phaseReadoutRef = useRef<HTMLSpanElement | null>(null);

  // Sync key animation engine state to body dataset
  useEffect(() => {
    document.body.dataset.character = character;
    document.body.dataset.state = isPlaying ? 'playing' : 'paused';
    document.body.dataset.gait = clipId;
    document.body.dataset.interp = interpMode;
    document.body.dataset.locomotion = locomotionMode;
  }, [character, isPlaying, clipId, interpMode, locomotionMode]);

  // Collapse inspector automatically when resized below desktop lg breakpoint
  useEffect(() => {
    const mq = window.matchMedia('(min-width: 1024px)');
    const onChange = (e: MediaQueryListEvent) => {
      setInspectorOpen(e.matches);
    };
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, []);

  // Global hotkeys (Space = Play/Pause, 1-4 = Gait Clips, R = Rig Overlay)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }
      const order = getCharacterClipOrder(character);
      if (e.code === 'Space') {
        e.preventDefault();
        setIsPlaying((prev) => !prev);
      } else if (e.key === '1' && order[0]) {
        setClipId(order[0]);
      } else if (e.key === '2' && order[1]) {
        setClipId(order[1]);
      } else if (e.key === '3' && order[2]) {
        setClipId(order[2]);
      } else if (e.key === '4' && order[3]) {
        setClipId(order[3]);
      } else if (e.key === 'r' || e.key === 'R') {
        setShowRigOverlay((prev) => !prev);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [character]);

  const handleSelectCharacter = useCallback((next: CharacterId) => {
    setScrubPhase(null);
    setCharacter((prev) => {
      if (prev === next) return prev;
      setClipId((curClip) => mapClipBetweenCharacters(curClip, next));
      return next;
    });
  }, []);

  const handleTogglePlay = useCallback(() => {
    setScrubPhase(null);
    setIsPlaying((prev) => !prev);
  }, []);

  const handleStepFrame = useCallback(() => {
    setIsPlaying(false);
    setScrubPhase(null);
    setStepNonce((n) => n + 1);
  }, []);

  const handleJumpToKeyframe = useCallback((phase: number) => {
    setIsPlaying(false);
    setScrubPhase(phase);
    if (playheadRef.current) {
      playheadRef.current.value = phase.toFixed(3);
    }
    if (phaseReadoutRef.current) {
      phaseReadoutRef.current.textContent = phase.toFixed(2);
    }
  }, []);

  const handleSelectClip = useCallback((id: AnyClipId) => {
    setScrubPhase(null);
    setClipId(id);
    if (id !== 'idle' && id !== 'graze') {
      setIsPlaying(true);
    }
  }, []);

  return (
    <main className="relative w-screen h-screen overflow-hidden bg-[#0b0908]">
      {/* Full-Viewport 2D Top-Down Animation Stage */}
      <GsmCanvasStage
        character={character}
        clipId={clipId}
        interpMode={interpMode}
        locomotionMode={locomotionMode}
        lightingMode={lightingMode}
        isPlaying={isPlaying}
        speedMultiplier={speedMultiplier}
        creatureScale={creatureScale}
        showRigOverlay={showRigOverlay}
        scrubPhase={scrubPhase}
        stepNonce={stepNonce}
        playheadRef={playheadRef}
        phaseReadoutRef={phaseReadoutRef}
        onTelemetry={setTelemetry}
        onClipAutoSelect={setClipId}
        onRigReady={setRigTarget}
      />

      {/* Non-blocking Floating Studio HUD */}
      <div className="pointer-events-none fixed inset-0 flex flex-col justify-between p-4 sm:p-5">
        {/* Top Row: Editorial Title + Character Switcher + Inspector Toggle/Drawer */}
        <div className="flex flex-wrap items-start justify-between gap-2.5 sm:gap-4">
          <header className="pointer-events-auto max-w-md space-y-2">
            <div>
              <h1 className="font-display text-2xl sm:text-3xl font-semibold tracking-tight text-[#f5efe4] leading-tight">
                {character === 'sheep' ? 'NPC Sheep' : 'Giant Scary Monster'}
              </h1>
              <p className="mt-0.5 text-xs text-[#9e9484]">
                Hide in Sheep Clothing ·{' '}
                {character === 'sheep'
                  ? 'Quadruped Keyframe Gait Engine'
                  : '20-Leg Keyframe Gait Engine'}
              </p>
            </div>

            {/* Character Switcher */}
            <div
              role="group"
              aria-label="Character rig"
              className="inline-flex items-center gap-1 rounded-lg bg-[#13100d]/95 p-1 border border-[#d8cfb8]/14 shadow-lg"
            >
              <button
                type="button"
                aria-pressed={character === 'gsm'}
                onClick={() => handleSelectCharacter('gsm')}
                className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-[#e6dfd1] ${
                  character === 'gsm'
                    ? 'bg-[#2a221c] text-[#f5efe4] border border-[#c59b4c]/40'
                    : 'text-[#9e9484] border border-transparent hover:text-[#e6dfd1]'
                }`}
              >
                Giant Scary Monster
              </button>
              <button
                type="button"
                aria-pressed={character === 'sheep'}
                onClick={() => handleSelectCharacter('sheep')}
                className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-[#e6dfd1] ${
                  character === 'sheep'
                    ? 'bg-[#2a221c] text-[#f5efe4] border border-[#c59b4c]/40'
                    : 'text-[#9e9484] border border-transparent hover:text-[#e6dfd1]'
                }`}
              >
                NPC Sheep
              </button>
            </div>
          </header>

          <div className="flex items-start gap-2">
            {!inspectorOpen && (
              <button
                type="button"
                disabled={!rigTarget}
                onClick={() => setExportModalOpen(true)}
                aria-label="Export Godot 4.7 sprite sheet"
                className="pointer-events-auto inline-flex items-center gap-1.5 rounded-lg border border-[#c59b4c]/35 bg-[#13100d]/95 px-3 py-2 text-xs font-medium text-[#f5efe4] hover:bg-[#1e1914] disabled:opacity-50 transition-colors shadow-lg whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#e6dfd1]"
              >
                <Download className="w-3.5 h-3.5 text-[#c59b4c]" />
                <span>Godot Export</span>
              </button>
            )}

            <RigInspectorDrawer
              isOpen={inspectorOpen}
              onToggleOpen={() => setInspectorOpen((o) => !o)}
              character={character}
              clipId={clipId}
              interpMode={interpMode}
              locomotionMode={locomotionMode}
              lightingMode={lightingMode}
              creatureScale={creatureScale}
              showRigOverlay={showRigOverlay}
              telemetry={telemetry}
              canExportGodot={Boolean(rigTarget)}
              onChangeInterp={setInterpMode}
              onChangeLocomotion={setLocomotionMode}
              onChangeLighting={setLightingMode}
              onChangeScale={setCreatureScale}
              onToggleRigOverlay={() => setShowRigOverlay((r) => !r)}
              onOpenGodotExport={() => setExportModalOpen(true)}
            />
          </div>
        </div>

        {/* Bottom Dock: Playback, Gait Transitions & Keyframe Timeline */}
        <div className="w-full">
          <AnimationTimelineBar
            character={character}
            clipId={clipId}
            isPlaying={isPlaying}
            speedMultiplier={speedMultiplier}
            playheadRef={playheadRef}
            phaseReadoutRef={phaseReadoutRef}
            onSelectClip={handleSelectClip}
            onTogglePlay={handleTogglePlay}
            onStepFrame={handleStepFrame}
            onSelectSpeed={setSpeedMultiplier}
            onScrubStart={() => setIsPlaying(false)}
            onScrubChange={(val) => setScrubPhase(val)}
            onScrubEnd={() => setScrubPhase(null)}
            onJumpToKeyframe={handleJumpToKeyframe}
          />
        </div>
      </div>

      <GodotExportModal
        isOpen={exportModalOpen}
        onClose={() => setExportModalOpen(false)}
        character={character}
        rigTarget={rigTarget}
        interpMode={interpMode}
      />
    </main>
  );
}
