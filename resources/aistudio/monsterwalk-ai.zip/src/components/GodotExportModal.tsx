import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Check, Download, FileCode2, Film, Grid, Image as ImageIcon, Package, X } from 'lucide-react';
import {
  BakedGodotBundle,
  GodotBakeTarget,
  GodotClipBakeSpec,
  GodotFacing,
  bakeGodotSpriteSheet,
  buildZipArchive,
  getDefaultGodotClips,
  getGodotAssetNames,
} from '../engine/godotExport';
import { AnyClipId, CharacterId, InterpolationMode } from '../engine/keyframes';

interface GodotExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  character: CharacterId;
  rigTarget: GodotBakeTarget | null;
  interpMode: InterpolationMode;
}

const FRAME_SIZES: (256 | 320 | 384)[] = [256, 320, 384];

function triggerBlobDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}

function canvasToPngUint8Array(canvas: HTMLCanvasElement): Promise<Uint8Array> {
  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => {
      if (!blob) {
        reject(new Error('Failed to encode sprite sheet PNG'));
        return;
      }
      blob.arrayBuffer().then((buf) => resolve(new Uint8Array(buf))).catch(reject);
    }, 'image/png');
  });
}

function buildInitialEnabledMap(clips: GodotClipBakeSpec[]): Record<string, boolean> {
  const map: Record<string, boolean> = {};
  for (const c of clips) map[c.clipId] = true;
  return map;
}

export const GodotExportModal: React.FC<GodotExportModalProps> = ({
  isOpen,
  onClose,
  character,
  rigTarget,
  interpMode,
}) => {
  const [frameSize, setFrameSize] = useState<256 | 320 | 384>(384);
  const [facing, setFacing] = useState<GodotFacing>('godot_right');
  const [includeShadow, setIncludeShadow] = useState<boolean>(true);
  const defaultClips = useMemo(() => getDefaultGodotClips(character), [character]);
  const assetNames = useMemo(() => getGodotAssetNames(character), [character]);

  const [enabledClips, setEnabledClips] = useState<Record<string, boolean>>(() =>
    buildInitialEnabledMap(getDefaultGodotClips(character))
  );
  const [previewMode, setPreviewMode] = useState<'loop' | 'sheet'>('loop');
  const [previewClipId, setPreviewClipId] = useState<AnyClipId>('walk');
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [lastDownloaded, setLastDownloaded] = useState<string | null>(null);

  const previewCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Reset clip selection & status cleanly when character switches
  useEffect(() => {
    setEnabledClips(buildInitialEnabledMap(defaultClips));
    setPreviewClipId('walk');
    setLastDownloaded(null);
  }, [character, defaultClips]);

  const selectedClips: GodotClipBakeSpec[] = useMemo(
    () => defaultClips.filter((c) => enabledClips[c.clipId]),
    [defaultClips, enabledClips]
  );

  // Ensure previewClipId always points to an enabled clip
  useEffect(() => {
    if (!enabledClips[previewClipId] && selectedClips.length > 0) {
      setPreviewClipId(selectedClips[0].clipId);
    }
  }, [enabledClips, previewClipId, selectedClips]);

  // Bake sprite sheet synchronously whenever modal is open and settings change
  const bundle: BakedGodotBundle | null = useMemo(() => {
    if (!isOpen || !rigTarget || rigTarget.character !== character || selectedClips.length === 0) {
      return null;
    }
    return bakeGodotSpriteSheet(rigTarget, {
      frameSize,
      interpMode,
      includeShadow,
      facing,
      clips: selectedClips,
    });
  }, [isOpen, rigTarget, character, frameSize, interpMode, includeShadow, facing, selectedClips]);

  // Close on Escape
  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isOpen, onClose]);

  // Animate discrete baked frame loop or render full sprite sheet minimap
  useEffect(() => {
    if (!isOpen || !bundle) return;
    const canvas = previewCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const size = 264;
    if (canvas.width !== size || canvas.height !== size) {
      canvas.width = size;
      canvas.height = size;
    }

    const drawChecker = () => {
      const cell = 12;
      for (let y = 0; y < size; y += cell) {
        for (let x = 0; x < size; x += cell) {
          const even = ((x / cell) + (y / cell)) % 2 === 0;
          ctx.fillStyle = even ? '#14110e' : '#1b1713';
          ctx.fillRect(x, y, cell, cell);
        }
      }
    };

    if (previewMode === 'sheet') {
      drawChecker();
      const pad = 10;
      const avail = size - pad * 2;
      const fitScale = Math.min(avail / bundle.canvas.width, avail / bundle.canvas.height);
      const dw = bundle.canvas.width * fitScale;
      const dh = bundle.canvas.height * fitScale;
      const ox = (size - dw) * 0.5;
      const oy = (size - dh) * 0.5;
      ctx.drawImage(bundle.canvas, ox, oy, dw, dh);

      // Subtle grid lines showing individual cell boundaries
      ctx.strokeStyle = 'rgba(197, 155, 76, 0.22)';
      ctx.lineWidth = 1;
      const cellW = bundle.layout.frameSize * fitScale;
      for (let c = 0; c <= bundle.layout.columns; c++) {
        const gx = Math.round(ox + c * cellW) + 0.5;
        ctx.beginPath();
        ctx.moveTo(gx, oy);
        ctx.lineTo(gx, oy + dh);
        ctx.stroke();
      }
      for (let r = 0; r <= bundle.layout.rows; r++) {
        const gy = Math.round(oy + r * cellW) + 0.5;
        ctx.beginPath();
        ctx.moveTo(ox, gy);
        ctx.lineTo(ox + dw, gy);
        ctx.stroke();
      }
      return;
    }

    const activeClip =
      bundle.layout.clips.find((c) => c.clipId === previewClipId) ?? bundle.layout.clips[0];
    if (!activeClip) return;

    let rafId = 0;
    const start = performance.now();
    let lastDrawnFrame = -1;

    const tick = (now: number) => {
      const elapsedSec = (now - start) / 1000;
      const rawIdx = Math.floor(elapsedSec * activeClip.fps);
      const localIdx = rawIdx % activeClip.frameCount;
      if (localIdx !== lastDrawnFrame) {
        lastDrawnFrame = localIdx;
        const frame = bundle.layout.frames[activeClip.startIndex + localIdx];
        drawChecker();
        if (frame) {
          ctx.drawImage(
            bundle.canvas,
            frame.x,
            frame.y,
            frame.w,
            frame.h,
            8,
            8,
            size - 16,
            size - 16
          );
        }
      }
      rafId = requestAnimationFrame(tick);
    };
    rafId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafId);
  }, [isOpen, bundle, previewMode, previewClipId]);

  if (!isOpen) return null;

  const toggleClip = (id: AnyClipId) => {
    setEnabledClips((prev) => {
      const next = { ...prev, [id]: !prev[id] };
      const count = Object.values(next).filter(Boolean).length;
      return count >= 1 ? next : prev;
    });
  };

  const handleDownloadZip = async () => {
    if (!bundle || isExporting) return;
    setIsExporting(true);
    try {
      const pngBytes = await canvasToPngUint8Array(bundle.canvas);
      const enc = new TextEncoder();
      const zipBytes = buildZipArchive([
        { name: `assets/${assetNames.sheetName}`, data: pngBytes },
        { name: `assets/${assetNames.tresName}`, data: enc.encode(bundle.tresContent) },
        { name: 'README_GODOT_4_7.txt', data: enc.encode(bundle.readmeContent) },
      ]);
      const zipBuffer = new ArrayBuffer(zipBytes.byteLength);
      new Uint8Array(zipBuffer).set(zipBytes);
      triggerBlobDownload(new Blob([zipBuffer], { type: 'application/zip' }), assetNames.zipName);
      setLastDownloaded(assetNames.zipName);
    } finally {
      setIsExporting(false);
    }
  };

  const handleDownloadPng = async () => {
    if (!bundle || isExporting) return;
    setIsExporting(true);
    try {
      const pngBytes = await canvasToPngUint8Array(bundle.canvas);
      const pngBuffer = new ArrayBuffer(pngBytes.byteLength);
      new Uint8Array(pngBuffer).set(pngBytes);
      triggerBlobDownload(new Blob([pngBuffer], { type: 'image/png' }), assetNames.sheetName);
      setLastDownloaded(assetNames.sheetName);
    } finally {
      setIsExporting(false);
    }
  };

  const handleDownloadTres = () => {
    if (!bundle) return;
    triggerBlobDownload(
      new Blob([bundle.tresContent], { type: 'text/plain;charset=utf-8' }),
      assetNames.tresName
    );
    setLastDownloaded(assetNames.tresName);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="godot-export-title"
      className="pointer-events-auto fixed inset-0 z-50 flex items-center justify-center bg-[#060504]/80 p-3 sm:p-6"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="w-full max-w-3xl max-h-[92vh] overflow-y-auto rounded-xl border border-[#d8cfb8]/18 bg-[#13100d] p-4 sm:p-6 shadow-[0_30px_80px_rgba(0,0,0,0.9)] text-[#e6dfd1]">
        {/* Header */}
        <div className="flex items-start justify-between gap-3 pb-3.5 border-b border-[#d8cfb8]/10">
          <div>
            <h2
              id="godot-export-title"
              className="font-display text-xl sm:text-2xl font-semibold tracking-wide text-[#f5efe4]"
            >
              Export Godot 4.7 SpriteFrames Pack
            </h2>
            <p className="mt-0.5 text-xs text-[#9e9484]">
              {assetNames.title} · Baked transparent PNG sheet + <code className="text-[#c59b4c]">AnimatedSprite2D</code> resource
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Godot export dialog"
            className="p-1.5 rounded-md text-[#9e9484] hover:text-[#f5efe4] hover:bg-[#1f1a15] transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-[#e6dfd1]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {!rigTarget || !bundle ? (
          <div className="py-12 text-center text-sm text-[#a89e8c]">
            Waiting for {character === 'sheep' ? 'NPC Sheep' : '20-leg'} rig extraction…
          </div>
        ) : (
          <div className="mt-4 grid grid-cols-1 md:grid-cols-[264px_1fr] gap-5">
            {/* Left Column: Live Discrete Playback / Packed Sheet Preview */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-[#c7bcae]">Baked Preview</span>
                <div
                  role="group"
                  aria-label="Preview view mode"
                  className="inline-flex rounded-md bg-[#0b0908] p-0.5 border border-[#d8cfb8]/10"
                >
                  <button
                    type="button"
                    aria-pressed={previewMode === 'loop'}
                    onClick={() => setPreviewMode('loop')}
                    className={`inline-flex items-center gap-1 px-2 py-1 rounded text-[11px] font-medium transition-colors whitespace-nowrap cursor-pointer border ${
                      previewMode === 'loop'
                        ? 'bg-[#2a221c] text-[#f5efe4] border-[#c59b4c]/40'
                        : 'text-[#8f8575] border-transparent hover:text-[#d8cfb8]'
                    }`}
                  >
                    <Film className="w-3 h-3" />
                    <span>Loop</span>
                  </button>
                  <button
                    type="button"
                    aria-pressed={previewMode === 'sheet'}
                    onClick={() => setPreviewMode('sheet')}
                    className={`inline-flex items-center gap-1 px-2 py-1 rounded text-[11px] font-medium transition-colors whitespace-nowrap cursor-pointer border ${
                      previewMode === 'sheet'
                        ? 'bg-[#2a221c] text-[#f5efe4] border-[#c59b4c]/40'
                        : 'text-[#8f8575] border-transparent hover:text-[#d8cfb8]'
                    }`}
                  >
                    <Grid className="w-3 h-3" />
                    <span>Sheet</span>
                  </button>
                </div>
              </div>

              <canvas
                ref={previewCanvasRef}
                data-testid="godot-export-preview"
                className="w-[264px] h-[264px] mx-auto block rounded-lg border border-[#d8cfb8]/14 bg-[#14110e]"
              />

              {previewMode === 'loop' && (
                <div className="flex flex-wrap gap-1 justify-center">
                  {bundle.layout.clips.map((c) => (
                    <button
                      key={c.clipId}
                      type="button"
                      aria-pressed={previewClipId === c.clipId}
                      onClick={() => setPreviewClipId(c.clipId)}
                      className={`px-2 py-1 rounded text-[11px] font-mono-tabular transition-colors whitespace-nowrap cursor-pointer ${
                        previewClipId === c.clipId
                          ? 'bg-[#2a221c] text-[#f5efe4] border border-[#c59b4c]/40'
                          : 'bg-[#0b0908] text-[#8f8575] border border-[#d8cfb8]/10 hover:text-[#d8cfb8]'
                      }`}
                    >
                      {c.godotName} ({c.fps}fps)
                    </button>
                  ))}
                </div>
              )}

              {/* Sheet Telemetry */}
              <div className="grid grid-cols-3 gap-2 rounded-lg bg-[#0b0908] border border-[#d8cfb8]/10 p-2.5 text-center">
                <div>
                  <div className="text-[10px] text-[#8f8575]">Sheet Size</div>
                  <div className="font-mono-tabular text-xs text-[#f5efe4]">
                    {bundle.layout.sheetWidth}×{bundle.layout.sheetHeight}
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-[#8f8575]">Frames</div>
                  <div className="font-mono-tabular text-xs text-[#c59b4c]">
                    {bundle.layout.totalFrames}
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-[#8f8575]">RGBA8 VRAM</div>
                  <div className="font-mono-tabular text-xs text-[#d8cfb8]">
                    {bundle.layout.estimatedVramMb.toFixed(1)} MB
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column: Configuration & Downloads */}
            <div className="space-y-4">
              {/* Frame Resolution */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-medium text-[#c7bcae]">Frame Resolution</span>
                  <span className="font-mono-tabular text-[#8f8575]">WebGL2 Safe (&le;4096px)</span>
                </div>
                <div
                  role="group"
                  aria-label="Baked frame resolution"
                  className="grid grid-cols-3 gap-1 rounded-lg bg-[#0b0908] p-1 border border-[#d8cfb8]/10"
                >
                  {FRAME_SIZES.map((sz) => (
                    <button
                      key={sz}
                      type="button"
                      aria-pressed={frameSize === sz}
                      onClick={() => setFrameSize(sz)}
                      className={`py-1.5 px-2 rounded-md text-xs font-mono-tabular transition-colors whitespace-nowrap cursor-pointer ${
                        frameSize === sz
                          ? 'bg-[#2a221c] text-[#f5efe4]'
                          : 'text-[#8f8575] hover:text-[#d8cfb8]'
                      }`}
                    >
                      {sz}×{sz} px
                    </button>
                  ))}
                </div>
              </div>

              {/* Godot Facing Alignment */}
              <div className="space-y-1.5">
                <span className="block text-xs font-medium text-[#c7bcae]">
                  Sprite Forward Axis
                </span>
                <div
                  role="group"
                  aria-label="Godot sprite forward axis"
                  className="grid grid-cols-2 gap-1 rounded-lg bg-[#0b0908] p-1 border border-[#d8cfb8]/10"
                >
                  <button
                    type="button"
                    aria-pressed={facing === 'godot_right'}
                    onClick={() => setFacing('godot_right')}
                    className={`py-1.5 px-2 rounded-md text-xs font-medium transition-colors whitespace-nowrap cursor-pointer ${
                      facing === 'godot_right'
                        ? 'bg-[#2a221c] text-[#f5efe4]'
                        : 'text-[#8f8575] hover:text-[#d8cfb8]'
                    }`}
                  >
                    +X Right (Godot 0 rad)
                  </button>
                  <button
                    type="button"
                    aria-pressed={facing === 'up'}
                    onClick={() => setFacing('up')}
                    className={`py-1.5 px-2 rounded-md text-xs font-medium transition-colors whitespace-nowrap cursor-pointer ${
                      facing === 'up'
                        ? 'bg-[#2a221c] text-[#f5efe4]'
                        : 'text-[#8f8575] hover:text-[#d8cfb8]'
                    }`}
                  >
                    -Y Up (Canvas)
                  </button>
                </div>
              </div>

              {/* Included Clips */}
              <div className="space-y-1.5">
                <span className="block text-xs font-medium text-[#c7bcae]">
                  Animations Included in <code className="text-[#c59b4c]">SpriteFrames</code>
                </span>
                <div className="grid grid-cols-2 gap-1.5">
                  {defaultClips.map((clip) => {
                    const checked = Boolean(enabledClips[clip.clipId]);
                    return (
                      <button
                        key={clip.clipId}
                        type="button"
                        role="checkbox"
                        aria-checked={checked}
                        onClick={() => toggleClip(clip.clipId)}
                        className={`flex items-center justify-between rounded-lg border px-2.5 py-2 text-xs transition-colors cursor-pointer ${
                          checked
                            ? 'border-[#c59b4c]/40 bg-[#231d17] text-[#f5efe4]'
                            : 'border-[#d8cfb8]/10 bg-[#0b0908] text-[#8f8575]'
                        }`}
                      >
                        <span className="flex items-center gap-2 font-medium whitespace-nowrap">
                          <span
                            className={`w-3.5 h-3.5 rounded flex items-center justify-center border ${
                              checked
                                ? 'bg-[#c59b4c] border-[#c59b4c] text-[#0b0908]'
                                : 'border-[#8f8575]/50'
                            }`}
                          >
                            {checked && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                          </span>
                          <span>{clip.godotName}</span>
                        </span>
                        <span className="font-mono-tabular text-[11px] text-[#9e9484]">
                          {clip.frameCount}f · {clip.fps}fps
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Cast Shadow Toggle */}
              <button
                type="button"
                role="switch"
                aria-checked={includeShadow}
                onClick={() => setIncludeShadow((s) => !s)}
                className="w-full flex items-center justify-between rounded-lg border border-[#d8cfb8]/14 bg-[#1a1612] px-3 py-2 text-xs font-medium text-[#d8cfb8] hover:bg-[#231d17] transition-colors cursor-pointer"
              >
                <span className="whitespace-nowrap">Baked Elevation Drop Shadow</span>
                <span className="font-mono-tabular text-[#c59b4c]">
                  {includeShadow ? 'Included' : 'Omitted'}
                </span>
              </button>

              {/* Download Buttons */}
              <div className="pt-2 border-t border-[#d8cfb8]/10 space-y-2">
                <button
                  type="button"
                  disabled={isExporting}
                  onClick={handleDownloadZip}
                  className="w-full inline-flex items-center justify-center gap-2 rounded-lg bg-[#9e2a2b] px-4 py-2.5 text-xs font-medium text-[#f5efe4] hover:bg-[#b53334] disabled:opacity-50 transition-colors whitespace-nowrap cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#e6dfd1]"
                >
                  <Package className="w-4 h-4" />
                  <span>Download Godot Bundle (.zip)</span>
                </button>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    disabled={isExporting}
                    onClick={handleDownloadPng}
                    className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-[#d8cfb8]/18 bg-[#1d1814] px-3 py-2 text-xs font-medium text-[#d8cfb8] hover:bg-[#27201b] hover:text-[#f5efe4] transition-colors whitespace-nowrap cursor-pointer"
                  >
                    <ImageIcon className="w-3.5 h-3.5 text-[#c59b4c]" />
                    <span>PNG Sheet</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleDownloadTres}
                    className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-[#d8cfb8]/18 bg-[#1d1814] px-3 py-2 text-xs font-medium text-[#d8cfb8] hover:bg-[#27201b] hover:text-[#f5efe4] transition-colors whitespace-nowrap cursor-pointer"
                  >
                    <FileCode2 className="w-3.5 h-3.5 text-[#c59b4c]" />
                    <span>SpriteFrames .tres</span>
                  </button>
                </div>

                {lastDownloaded && (
                  <p className="flex items-center justify-center gap-1.5 text-[11px] text-[#c59b4c]">
                    <Download className="w-3 h-3" />
                    <span>Downloaded {lastDownloaded}</span>
                  </p>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
