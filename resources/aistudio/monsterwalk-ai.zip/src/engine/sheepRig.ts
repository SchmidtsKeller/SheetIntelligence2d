import type { Side, Vec2 } from './gsmRig';

export type SheepLegId = 'RL' | 'FL' | 'RR' | 'FR';

export interface SheepLegRigSpec {
  id: SheepLegId;
  side: Side;
  /** 0 = rear limb, 1 = front limb */
  index: 0 | 1;
  /** Root hip/shoulder socket in 1024x1024 normalized sheep coordinates */
  root: Vec2;
  /** Neutral hoof tip position in 1024x1024 coordinates */
  restTip: Vec2;
  /** Bone vector from root socket to hoof tip */
  boneLength: number;
  /** Natural outward splay angle (radians) from +Y axis */
  restAngle: number;
  /** Swing amplitude gain */
  swingGain: number;
}

export const SHEEP_SOURCE_SIZE = 1024;
export const SHEEP_RUMP_CENTER: Vec2 = { x: 512, y: 315 };
export const SHEEP_BODY_CENTER: Vec2 = { x: 512, y: 495 };
export const SHEEP_HEAD_PIVOT: Vec2 = { x: 512, y: 742 };

/**
 * Calibrated top-down quadruped rig coordinates for /public/assets/aistudio/sheep_5ca2f489.jpg
 * normalized to 1024x1024 (source is 2048x2048).
 * Sheep faces +Y (rump at y~80, widest wool barrel y~420..525, ears y~780, snout y~928).
 */
export const SHEEP_LEG_SPECS: SheepLegRigSpec[] = [
  {
    id: 'RL',
    side: 'L',
    index: 0,
    root: { x: 404, y: 332 },
    restTip: { x: 374, y: 344 },
    boneLength: 36,
    restAngle: 1.38,
    swingGain: 0.96,
  },
  {
    id: 'FL',
    side: 'L',
    index: 1,
    root: { x: 408, y: 632 },
    restTip: { x: 378, y: 644 },
    boneLength: 36,
    restAngle: 1.32,
    swingGain: 1.04,
  },
  {
    id: 'RR',
    side: 'R',
    index: 0,
    root: { x: 620, y: 332 },
    restTip: { x: 650, y: 344 },
    boneLength: 36,
    restAngle: -1.38,
    swingGain: 0.96,
  },
  {
    id: 'FR',
    side: 'R',
    index: 1,
    root: { x: 616, y: 632 },
    restTip: { x: 646, y: 644 },
    boneLength: 36,
    restAngle: -1.32,
    swingGain: 1.04,
  },
];

export type SheepPartRegion = 'rump' | 'torso' | 'head';

/**
 * Returns soft blend weights [rump, torso, head] for a 1024x1024 normalized pixel
 * on the sheep sprite, with generous feathered seams so articulated layers never tear.
 */
export function sheepRegionWeights(y: number): {
  rump: number;
  torso: number;
  head: number;
} {
  // Rump fleece: full up to y=375, feathers out to 0 at y=505
  let rump = 0;
  if (y <= 375) rump = 1;
  else if (y < 505) rump = 1 - (y - 375) / 130;

  // Main barrel torso: feathers in 310..440, full 440..675, feathers out 675..755
  let torso = 0;
  if (y >= 310 && y <= 755) {
    if (y < 440) torso = (y - 310) / 130;
    else if (y <= 675) torso = 1;
    else torso = 1 - (y - 675) / 80;
  }

  // Head & neck: feathers in 685..745, full 745+
  let head = 0;
  if (y >= 685) {
    head = y < 745 ? (y - 685) / 60 : 1;
  }

  return { rump, torso, head };
}
