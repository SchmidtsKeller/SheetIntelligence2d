import {
  AnyClipId,
  CharacterId,
  InterpolationMode,
  evaluateBodyPose,
  evaluateLegPose,
  evaluateSheepBodyPose,
  evaluateSheepLegPose,
  getCharacterClip,
} from './keyframes';
import type { ExtractedGsmRig } from './spriteExtractor';
import { renderGsmCreature } from './spriteExtractor';
import type { ExtractedSheepRig } from './sheepExtractor';
import { renderSheepCreature } from './sheepExtractor';

export type GodotFacing = 'godot_right' | 'up';

export interface GodotClipBakeSpec {
  clipId: AnyClipId;
  godotName: string;
  frameCount: number;
  fps: number;
  loop: boolean;
}

export interface GodotExportOptions {
  frameSize: 256 | 320 | 384;
  interpMode: InterpolationMode;
  includeShadow: boolean;
  facing: GodotFacing;
  clips: GodotClipBakeSpec[];
}

export interface BakedClipRegion {
  clipId: AnyClipId;
  godotName: string;
  fps: number;
  loop: boolean;
  startIndex: number;
  frameCount: number;
}

export interface SheetFrameRect {
  index: number;
  clipId: AnyClipId;
  frameInClip: number;
  phase: number;
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface GodotSheetLayout {
  frameSize: number;
  columns: number;
  rows: number;
  sheetWidth: number;
  sheetHeight: number;
  totalFrames: number;
  estimatedVramMb: number;
  clips: BakedClipRegion[];
  frames: SheetFrameRect[];
}

export const DEFAULT_GODOT_CLIPS: GodotClipBakeSpec[] = [
  { clipId: 'idle', godotName: 'idle', frameCount: 16, fps: 12, loop: true },
  { clipId: 'stalk', godotName: 'stalk', frameCount: 20, fps: 14, loop: true },
  { clipId: 'walk', godotName: 'walk', frameCount: 22, fps: 25, loop: true },
  { clipId: 'lunge', godotName: 'eat_lunge', frameCount: 14, fps: 24, loop: false },
];

export const DEFAULT_SHEEP_GODOT_CLIPS: GodotClipBakeSpec[] = [
  { clipId: 'idle', godotName: 'idle', frameCount: 14, fps: 10, loop: true },
  { clipId: 'graze', godotName: 'graze', frameCount: 20, fps: 12, loop: true },
  { clipId: 'walk', godotName: 'walk', frameCount: 18, fps: 20, loop: true },
  { clipId: 'sprint', godotName: 'sprint', frameCount: 14, fps: 24, loop: true },
];

export function getDefaultGodotClips(character: CharacterId): GodotClipBakeSpec[] {
  return character === 'sheep' ? DEFAULT_SHEEP_GODOT_CLIPS : DEFAULT_GODOT_CLIPS;
}

export function getGodotAssetNames(character: CharacterId): {
  title: string;
  zipName: string;
  sheetName: string;
  tresName: string;
  resPath: string;
} {
  if (character === 'sheep') {
    return {
      title: 'NPC Sheep',
      zipName: 'npc_sheep_godot_pack.zip',
      sheetName: 'npc_sheep_sheet.png',
      tresName: 'npc_sheep_frames.tres',
      resPath: 'res://assets/npc_sheep_sheet.png',
    };
  }
  return {
    title: 'Giant Scary Monster (GSM)',
    zipName: 'gsm_godot_pack.zip',
    sheetName: 'gsm_spider_sheet.png',
    tresName: 'gsm_spider_frames.tres',
    resPath: 'res://assets/gsm_spider_sheet.png',
  };
}

/**
 * Computes a compact grid sprite-sheet layout guaranteed to fit cleanly within
 * WebGL2 / mobile Godot texture limits (<= 4096px wide when frameSize <= 384).
 */
export function computeSheetLayout(
  frameSize: number,
  clips: GodotClipBakeSpec[]
): GodotSheetLayout {
  const activeClips = clips.filter((c) => c.frameCount > 0);
  const totalFrames = activeClips.reduce((sum, c) => sum + c.frameCount, 0);

  if (totalFrames === 0) {
    return {
      frameSize,
      columns: 1,
      rows: 1,
      sheetWidth: frameSize,
      sheetHeight: frameSize,
      totalFrames: 0,
      estimatedVramMb: (frameSize * frameSize * 4) / (1024 * 1024),
      clips: [],
      frames: [],
    };
  }

  const maxColsBy4096 = Math.max(1, Math.floor(4096 / frameSize));
  const idealCols = Math.ceil(Math.sqrt(totalFrames));
  const columns = Math.min(maxColsBy4096, Math.max(1, idealCols));
  const rows = Math.ceil(totalFrames / columns);

  const sheetWidth = columns * frameSize;
  const sheetHeight = rows * frameSize;

  const frames: SheetFrameRect[] = [];
  const clipRegions: BakedClipRegion[] = [];
  let cursor = 0;

  for (const clip of activeClips) {
    const startIndex = cursor;
    for (let f = 0; f < clip.frameCount; f++) {
      const col = cursor % columns;
      const row = Math.floor(cursor / columns);
      // Sample [0, 1) evenly without duplicating t=0 and t=1 on cyclic clips
      const phase = clip.loop
        ? f / clip.frameCount
        : clip.frameCount > 1
          ? f / (clip.frameCount - 1)
          : 0;

      frames.push({
        index: cursor,
        clipId: clip.clipId,
        frameInClip: f,
        phase,
        x: col * frameSize,
        y: row * frameSize,
        w: frameSize,
        h: frameSize,
      });
      cursor++;
    }
    clipRegions.push({
      clipId: clip.clipId,
      godotName: clip.godotName,
      fps: clip.fps,
      loop: clip.loop,
      startIndex,
      frameCount: clip.frameCount,
    });
  }

  const estimatedVramMb = (sheetWidth * sheetHeight * 4) / (1024 * 1024);

  return {
    frameSize,
    columns,
    rows,
    sheetWidth,
    sheetHeight,
    totalFrames,
    estimatedVramMb,
    clips: clipRegions,
    frames,
  };
}

/**
 * Generates a valid Godot 4.x SpriteFrames `.tres` resource referencing
 * `res://assets/gsm_spider_sheet.png` with AtlasTexture sub-resources for every frame.
 */
export function generateGodotSpriteFramesTres(
  layout: GodotSheetLayout,
  textureResPath = 'res://assets/gsm_spider_sheet.png'
): string {
  const loadSteps = layout.totalFrames + 2;
  const lines: string[] = [
    `[gd_resource type="SpriteFrames" load_steps=${loadSteps} format=3]`,
    '',
    `[ext_resource type="Texture2D" path="${textureResPath}" id="1_sheet"]`,
    '',
  ];

  for (const frame of layout.frames) {
    const id = `AtlasTexture_f${frame.index}`;
    lines.push(`[sub_resource type="AtlasTexture" id="${id}"]`);
    lines.push(`atlas = ExtResource("1_sheet")`);
    lines.push(`region = Rect2(${frame.x}, ${frame.y}, ${frame.w}, ${frame.h})`);
    lines.push('');
  }

  lines.push('[resource]');
  lines.push('animations = [');

  layout.clips.forEach((clip, clipIdx) => {
    lines.push('{');
    lines.push('"frames": [');
    for (let i = 0; i < clip.frameCount; i++) {
      const subId = `AtlasTexture_f${clip.startIndex + i}`;
      const comma = i < clip.frameCount - 1 ? ',' : '';
      lines.push(`{"duration": 1.0, "texture": SubResource("${subId}")}${comma}`);
    }
    lines.push('],');
    lines.push(`"loop": ${clip.loop ? 'true' : 'false'},`);
    lines.push(`"name": &"${clip.godotName}",`);
    lines.push(`"speed": ${clip.fps.toFixed(1)}`);
    const clipComma = clipIdx < layout.clips.length - 1 ? ',' : '';
    lines.push(`}${clipComma}`);
  });

  lines.push(']');
  lines.push('');
  return lines.join('\n');
}

export function generateGodotReadme(
  layout: GodotSheetLayout,
  facing: GodotFacing,
  character: CharacterId = 'gsm'
): string {
  const facingNote =
    facing === 'godot_right'
      ? 'Sprites face +X (right), matching Godot 2D rotation = 0 rad (look_at ready).'
      : 'Sprites face -Y (up), matching standard top-down canvas orientation.';
  const names = getGodotAssetNames(character);

  const setupLines =
    character === 'sheep'
      ? [
          'Setup in Godot 4.7 (Hide in Sheep Clothing — NPC Flock & Disguised Monster):',
          `1. Copy \`${names.sheetName}\` and \`${names.tresName}\` into \`res://assets/\`.`,
          '2. Add an `AnimatedSprite2D` node inside `NPCSheep (CharacterBody2D)` and `MonsterSheep`.',
          `3. Assign \`${names.tresName}\` to its \`Sprite Frames\` property.`,
          '4. For Strict Fog of War (visible only inside the Sheepherder flashlight cone):',
          '   Assign a `CanvasItemMaterial` with `light_mode = LIGHT_MODE_ONLY` (`Light Only`)',
          '   to the `AnimatedSprite2D` for dynamic flock entities.',
          '5. Call `sprite.play("walk")` at 180 px/s, `sprite.play("graze")` when nibbling grass,',
          '   `sprite.play("idle")` when standing, and `sprite.play("sprint")` during Monster 270 px/s dash.',
        ]
      : [
          'Setup in Godot 4.7 (Hide in Sheep Clothing):',
          `1. Copy \`${names.sheetName}\` and \`${names.tresName}\` into \`res://assets/\`.`,
          '2. Add an `AnimatedSprite2D` node inside `MonsterSpider (CharacterBody2D)`.',
          `3. Assign \`${names.tresName}\` to its \`Sprite Frames\` property.`,
          '4. For Strict Fog of War (visible only inside the Sheepherder flashlight cone):',
          '   Assign a `CanvasItemMaterial` with `light_mode = LIGHT_MODE_ONLY` (`Light Only`)',
          '   to the `AnimatedSprite2D` (only on the Sheepherder local view / both clients if FoW applies).',
          '5. Call `sprite.play("walk")` when moving at 300 px/s, `sprite.play("idle")` when still,',
          '   and `sprite.play("eat_lunge")` when consuming a sheep or the Sheepherder.',
        ];

  return [
    `${names.title} — Godot 4.7 SpriteFrames Pack`,
    '======================================================',
    '',
    `Sheet Size: ${layout.sheetWidth} x ${layout.sheetHeight} px (${layout.frameSize}x${layout.frameSize} per frame)`,
    `Total Frames: ${layout.totalFrames} (~${layout.estimatedVramMb.toFixed(1)} MB RGBA8 VRAM)`,
    `Orientation: ${facingNote}`,
    '',
    'Animations included:',
    ...layout.clips.map(
      (c) => `  - ${c.godotName}: ${c.frameCount} frames @ ${c.fps} FPS (loop=${c.loop})`
    ),
    '',
    ...setupLines,
    '',
  ].join('\n');
}

// ================= ZERO-DEPENDENCY ZIP (STORE + CRC32) =================

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = (c & 1) !== 0 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    table[i] = c >>> 0;
  }
  return table;
})();

export function crc32(bytes: Uint8Array): number {
  let crc = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) {
    crc = CRC_TABLE[(crc ^ bytes[i]) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

export interface ZipEntryInput {
  name: string;
  data: Uint8Array;
}

/**
 * Builds an uncompressed (STORE) standard ZIP archive in pure TypeScript.
 * Works cleanly in both browser Blob downloads and Node unit tests.
 */
export function buildZipArchive(entries: ZipEntryInput[]): Uint8Array {
  const encoder = new TextEncoder();
  const localParts: Uint8Array[] = [];
  const centralParts: Uint8Array[] = [];
  let offset = 0;

  for (const entry of entries) {
    const nameBytes = encoder.encode(entry.name);
    const crc = crc32(entry.data);
    const size = entry.data.length;

    // Local file header (30 bytes + filename)
    const localHeader = new Uint8Array(30 + nameBytes.length);
    const lv = new DataView(localHeader.buffer);
    lv.setUint32(0, 0x04034b50, true); // Local file header signature
    lv.setUint16(4, 20, true); // Version needed
    lv.setUint16(6, 0x0800, true); // UTF-8 filename flag
    lv.setUint16(8, 0, true); // Compression method: 0 (STORE)
    lv.setUint16(10, 0, true); // Mod time
    lv.setUint16(12, 0x5421, true); // Mod date
    lv.setUint32(14, crc, true);
    lv.setUint32(18, size, true);
    lv.setUint32(22, size, true);
    lv.setUint16(26, nameBytes.length, true);
    lv.setUint16(28, 0, true); // Extra field length
    localHeader.set(nameBytes, 30);

    localParts.push(localHeader, entry.data);

    // Central directory header (46 bytes + filename)
    const centralHeader = new Uint8Array(46 + nameBytes.length);
    const cv = new DataView(centralHeader.buffer);
    cv.setUint32(0, 0x02014b50, true); // Central directory signature
    cv.setUint16(4, 20, true); // Version made by
    cv.setUint16(6, 20, true); // Version needed
    cv.setUint16(8, 0x0800, true); // UTF-8 flag
    cv.setUint16(10, 0, true); // Method: STORE
    cv.setUint16(12, 0, true); // Mod time
    cv.setUint16(14, 0x5421, true); // Mod date
    cv.setUint32(16, crc, true);
    cv.setUint32(20, size, true);
    cv.setUint32(24, size, true);
    cv.setUint16(28, nameBytes.length, true);
    cv.setUint16(30, 0, true); // Extra length
    cv.setUint16(32, 0, true); // Comment length
    cv.setUint16(34, 0, true); // Disk start
    cv.setUint16(36, 0, true); // Internal attrs
    cv.setUint32(38, 0, true); // External attrs
    cv.setUint32(42, offset, true); // Relative offset of local header
    centralHeader.set(nameBytes, 46);

    centralParts.push(centralHeader);
    offset += localHeader.length + entry.data.length;
  }

  const centralSize = centralParts.reduce((sum, p) => sum + p.length, 0);

  // End of central directory record (22 bytes)
  const eocd = new Uint8Array(22);
  const ev = new DataView(eocd.buffer);
  ev.setUint32(0, 0x06054b50, true);
  ev.setUint16(4, 0, true);
  ev.setUint16(6, 0, true);
  ev.setUint16(8, entries.length, true);
  ev.setUint16(10, entries.length, true);
  ev.setUint32(12, centralSize, true);
  ev.setUint32(16, offset, true);
  ev.setUint16(20, 0, true);

  const totalSize = offset + centralSize + eocd.length;
  const out = new Uint8Array(totalSize);
  let pos = 0;
  for (const part of localParts) {
    out.set(part, pos);
    pos += part.length;
  }
  for (const part of centralParts) {
    out.set(part, pos);
    pos += part.length;
  }
  out.set(eocd, pos);
  return out;
}

// ================= BROWSER SPRITE SHEET BAKER =================

export interface BakedGodotBundle {
  canvas: HTMLCanvasElement;
  layout: GodotSheetLayout;
  tresContent: string;
  readmeContent: string;
}

export type GodotBakeTarget =
  | { character: 'gsm'; rig: ExtractedGsmRig }
  | { character: 'sheep'; rig: ExtractedSheepRig };

/**
 * Renders every frame of the configured gait clips onto a transparent PNG sprite sheet
 * using the live keyframe animation engine for either GSM or NPC Sheep.
 */
export function bakeGodotSpriteSheet(
  target: GodotBakeTarget | ExtractedGsmRig,
  options: GodotExportOptions,
  legacyRenderFn?: typeof renderGsmCreature
): BakedGodotBundle {
  const normalizedTarget: GodotBakeTarget =
    'character' in target ? target : { character: 'gsm', rig: target };

  const layout = computeSheetLayout(options.frameSize, options.clips);
  const canvas = document.createElement('canvas');
  canvas.width = layout.sheetWidth;
  canvas.height = layout.sheetHeight;
  const ctx = canvas.getContext('2d')!;
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Sprite in source coords faces +Y.
  // godot_right (+X) => rotate -PI/2; up (-Y) => rotate PI.
  const spriteRot = options.facing === 'godot_right' ? -Math.PI / 2 : Math.PI;
  const localLightAngle = -0.78 - spriteRot;
  const lightDir = {
    x: Math.cos(localLightAngle),
    y: Math.sin(localLightAngle),
  };

  const sourceSize = normalizedTarget.rig.sourceSize;
  const fitRatio = normalizedTarget.character === 'sheep' ? 0.85 : 0.8;
  const scale = (options.frameSize * fitRatio) / sourceSize;
  const drawGsm = legacyRenderFn ?? renderGsmCreature;

  for (const frame of layout.frames) {
    const clip = getCharacterClip(normalizedTarget.character, frame.clipId);

    ctx.save();
    ctx.beginPath();
    ctx.rect(frame.x, frame.y, frame.w, frame.h);
    ctx.clip();

    ctx.translate(frame.x + frame.w * 0.5, frame.y + frame.h * 0.5);
    ctx.rotate(spriteRot);
    ctx.scale(scale, scale);

    if (normalizedTarget.character === 'sheep') {
      const rig = normalizedTarget.rig;
      const legPoses = rig.legs.map((leg) =>
        evaluateSheepLegPose(
          clip,
          leg.index,
          leg.side,
          frame.phase,
          options.interpMode,
          0
        )
      );
      const bodyPose = evaluateSheepBodyPose(clip, frame.phase, options.interpMode, 0);
      renderSheepCreature(ctx, rig, legPoses, bodyPose, {
        lightDir,
        showRigOverlay: false,
        includeShadow: options.includeShadow,
      });
    } else {
      const rig = normalizedTarget.rig;
      const legPoses = rig.legs.map((leg) =>
        evaluateLegPose(
          clip,
          leg.spec.index,
          leg.spec.side,
          frame.phase,
          options.interpMode,
          0
        )
      );
      const bodyPose = evaluateBodyPose(clip, frame.phase, options.interpMode, 0);
      drawGsm(ctx, rig, legPoses, bodyPose, {
        lightDir,
        showRigOverlay: false,
        includeShadow: options.includeShadow,
      });
    }
    ctx.restore();
  }

  const names = getGodotAssetNames(normalizedTarget.character);
  return {
    canvas,
    layout,
    tresContent: generateGodotSpriteFramesTres(layout, names.resPath),
    readmeContent: generateGodotReadme(layout, options.facing, normalizedTarget.character),
  };
}
