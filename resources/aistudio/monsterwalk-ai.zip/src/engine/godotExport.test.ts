import test from 'node:test';
import assert from 'node:assert/strict';
import {
  DEFAULT_GODOT_CLIPS,
  DEFAULT_SHEEP_GODOT_CLIPS,
  buildZipArchive,
  computeSheetLayout,
  crc32,
  generateGodotReadme,
  generateGodotSpriteFramesTres,
  getGodotAssetNames,
} from './godotExport';

test('computeSheetLayout fits default 4 clips at 384px safely inside 4096x4096 WebGL2 bounds', () => {
  const layout = computeSheetLayout(384, DEFAULT_GODOT_CLIPS);
  assert.equal(layout.totalFrames, 16 + 20 + 22 + 14);
  assert.ok(layout.sheetWidth <= 4096, `sheetWidth=${layout.sheetWidth} exceeds 4096`);
  assert.ok(layout.sheetHeight <= 4096, `sheetHeight=${layout.sheetHeight} exceeds 4096`);
  assert.equal(layout.frames.length, layout.totalFrames);

  // Verify no frame rects overlap or extend past sheet bounds
  const seen = new Set<string>();
  for (const f of layout.frames) {
    assert.ok(f.x >= 0 && f.x + f.w <= layout.sheetWidth);
    assert.ok(f.y >= 0 && f.y + f.h <= layout.sheetHeight);
    const key = `${f.x},${f.y}`;
    assert.ok(!seen.has(key), `Duplicate cell at ${key}`);
    seen.add(key);
  }
});

test('generateGodotSpriteFramesTres produces valid Godot 4 format=3 SpriteFrames resource', () => {
  const layout = computeSheetLayout(320, DEFAULT_GODOT_CLIPS);
  const tres = generateGodotSpriteFramesTres(layout, 'res://assets/gsm_spider_sheet.png');

  assert.ok(tres.startsWith(`[gd_resource type="SpriteFrames" load_steps=${layout.totalFrames + 2} format=3]`));
  assert.ok(tres.includes('[ext_resource type="Texture2D" path="res://assets/gsm_spider_sheet.png" id="1_sheet"]'));
  assert.ok(tres.includes('[sub_resource type="AtlasTexture" id="AtlasTexture_f0"]'));
  assert.ok(tres.includes(`id="AtlasTexture_f${layout.totalFrames - 1}"`));
  assert.ok(tres.includes('"name": &"walk"'));
  assert.ok(tres.includes('"loop": true'));
  assert.ok(tres.includes('"name": &"eat_lunge"'));
  assert.ok(tres.includes('"loop": false'));
});

test('NPC Sheep Godot 4.7 layout, .tres, and README use sheep clips and asset paths', () => {
  const layout = computeSheetLayout(384, DEFAULT_SHEEP_GODOT_CLIPS);
  assert.equal(layout.totalFrames, 14 + 20 + 18 + 14);
  assert.ok(layout.sheetWidth <= 4096);
  assert.ok(layout.sheetHeight <= 4096);

  const names = getGodotAssetNames('sheep');
  assert.equal(names.zipName, 'npc_sheep_godot_pack.zip');
  assert.equal(names.resPath, 'res://assets/npc_sheep_sheet.png');

  const tres = generateGodotSpriteFramesTres(layout, names.resPath);
  assert.ok(tres.includes('[ext_resource type="Texture2D" path="res://assets/npc_sheep_sheet.png" id="1_sheet"]'));
  assert.ok(tres.includes('"name": &"graze"'));
  assert.ok(tres.includes('"name": &"walk"'));
  assert.ok(tres.includes('"name": &"sprint"'));

  const readme = generateGodotReadme(layout, 'godot_right', 'sheep');
  assert.ok(readme.includes('NPC Sheep'));
  assert.ok(readme.includes('npc_sheep_sheet.png'));
});

test('buildZipArchive produces valid PKZIP headers and CRC32 checksums', () => {
  const enc = new TextEncoder();
  const sampleTres = enc.encode('[gd_resource type="SpriteFrames" format=3]\n');
  const fakePng = new Uint8Array([137, 80, 78, 71, 13, 10, 26, 10, 1, 2, 3, 4]);

  const zip = buildZipArchive([
    { name: 'gsm_spider_frames.tres', data: sampleTres },
    { name: 'gsm_spider_sheet.png', data: fakePng },
  ]);

  const view = new DataView(zip.buffer, zip.byteOffset, zip.byteLength);
  // Local file header PK\x03\x04
  assert.equal(view.getUint32(0, true), 0x04034b50);
  // Stored CRC matches helper
  assert.equal(view.getUint32(14, true), crc32(sampleTres));
  // EOCD PK\x05\x06 at end of 22-byte trailer
  assert.equal(view.getUint32(zip.length - 22, true), 0x06054b50);
  assert.equal(view.getUint16(zip.length - 12, true), 2);
});
