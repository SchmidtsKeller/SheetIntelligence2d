import { BodyPose, LegJointPose, SheepBodyPose } from './keyframes';
import type { Vec2 } from './gsmRig';
import {
  SHEEP_BODY_CENTER,
  SHEEP_HEAD_PIVOT,
  SHEEP_LEG_SPECS,
  SHEEP_RUMP_CENTER,
  SHEEP_SOURCE_SIZE,
  SheepLegRigSpec,
  sheepRegionWeights,
} from './sheepRig';

export interface SheepAtlasFrame {
  sx: number;
  sy: number;
  w: number;
  h: number;
  pivotX: number;
  pivotY: number;
}

export interface ExtractedSheepRig {
  sourceSize: number;
  atlas: HTMLCanvasElement;
  rump: SheepAtlasFrame;
  torso: SheepAtlasFrame;
  head: SheepAtlasFrame;
  bodyShadow: SheepAtlasFrame;
  legs: SheepLegRigSpec[];
}

function createCanvas(w: number, h: number): HTMLCanvasElement {
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.ceil(w));
  c.height = Math.max(1, Math.ceil(h));
  return c;
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error(`Failed to load sheep image: ${src}`));
    img.src = src;
  });
}

/**
 * Strips #FF00FF chroma-key background from JPEG-compressed sheep wool edges,
 * suppressing magenta JPEG compression halo completely so wool stays crisp
 * against dark chiaroscuro horror dirt.
 */
function chromaKeySheepPixel(
  r: number,
  g: number,
  b: number,
  a: number
): [number, number, number, number] {
  if (a === 0) return [0, 0, 0, 0];

  const rbMin = Math.min(r, b);
  const magentaExcess = rbMin - g;

  if (r > 165 && b > 165 && g < 110 && magentaExcess > 56) {
    return [0, 0, 0, 0];
  }

  let outR = r;
  let outG = g;
  let outB = b;
  let outA = a;

  if (magentaExcess > 10 && r > g && b > g) {
    const t = Math.max(0, Math.min(1, (magentaExcess - 10) / 52));
    outA = Math.round(a * (1 - t));
    // Clamp R & B down to warm wool tone anchored on G channel
    const warmR = Math.min(255, g + 12);
    const warmB = Math.max(0, g - 2);
    outR = Math.round(outR * (1 - t) + warmR * t);
    outB = Math.round(outB * (1 - t) + warmB * t);
  }

  return [outR, outG, outB, outA];
}

function cropMaskedRegion(
  clean: Uint8ClampedArray,
  size: number,
  minX: number,
  minY: number,
  maxX: number,
  maxY: number,
  pivotX: number,
  pivotY: number,
  weightFn: (x: number, y: number) => number
): { imageData: ImageData; w: number; h: number; pivotX: number; pivotY: number } {
  const x0 = Math.max(0, Math.floor(minX));
  const y0 = Math.max(0, Math.floor(minY));
  const x1 = Math.min(size - 1, Math.ceil(maxX));
  const y1 = Math.min(size - 1, Math.ceil(maxY));
  const w = Math.max(1, x1 - x0 + 1);
  const h = Math.max(1, y1 - y0 + 1);

  const imageData = new ImageData(w, h);
  const dst = imageData.data;

  for (let y = 0; y < h; y++) {
    const sy = y0 + y;
    for (let x = 0; x < w; x++) {
      const sx = x0 + x;
      const si = (sy * size + sx) * 4;
      const srcA = clean[si + 3];
      if (srcA === 0) continue;

      const factor = weightFn(sx, sy);
      if (factor <= 0.004) continue;

      const di = (y * w + x) * 4;
      dst[di] = clean[si];
      dst[di + 1] = clean[si + 1];
      dst[di + 2] = clean[si + 2];
      dst[di + 3] = Math.round(srcA * factor);
    }
  }

  return {
    imageData,
    w,
    h,
    pivotX: pivotX - x0,
    pivotY: pivotY - y0,
  };
}

/**
 * Extracts chroma-keyed rump, barrel torso, head/ears, and soft cast shadow
 * for the top-down NPC Sheep into a single Canvas2D texture atlas (no visible legs).
 */
export async function extractSheepRig(
  imageSrc = '/assets/aistudio/sheep_5ca2f489.jpg'
): Promise<ExtractedSheepRig> {
  const img = await loadImage(imageSrc);
  const size = SHEEP_SOURCE_SIZE;

  const srcCanvas = createCanvas(size, size);
  const srcCtx = srcCanvas.getContext('2d', { willReadFrequently: true })!;
  srcCtx.drawImage(img, 0, 0, size, size);
  const raw = srcCtx.getImageData(0, 0, size, size).data;

  const clean = new Uint8ClampedArray(raw.length);
  for (let i = 0; i < raw.length; i += 4) {
    const [r, g, b, a] = chromaKeySheepPixel(raw[i], raw[i + 1], raw[i + 2], raw[i + 3]);
    clean[i] = r;
    clean[i + 1] = g;
    clean[i + 2] = b;
    clean[i + 3] = a;
  }

  const rumpCrop = cropMaskedRegion(
    clean,
    size,
    250,
    60,
    774,
    515,
    SHEEP_RUMP_CENTER.x,
    SHEEP_RUMP_CENTER.y,
    (_x, y) => sheepRegionWeights(y).rump
  );

  const torsoCrop = cropMaskedRegion(
    clean,
    size,
    250,
    300,
    774,
    765,
    SHEEP_BODY_CENTER.x,
    SHEEP_BODY_CENTER.y,
    (_x, y) => sheepRegionWeights(y).torso
  );

  const headCrop = cropMaskedRegion(
    clean,
    size,
    330,
    680,
    694,
    945,
    SHEEP_HEAD_PIVOT.x,
    SHEEP_HEAD_PIVOT.y,
    (_x, y) => sheepRegionWeights(y).head
  );

  // Soft elliptical wool drop shadow
  const bsCanvas = createCanvas(520, 820);
  const bsCtx = bsCanvas.getContext('2d')!;
  const bsGrad = bsCtx.createRadialGradient(260, 410, 40, 260, 410, 380);
  bsGrad.addColorStop(0, 'rgba(3, 2, 2, 0.72)');
  bsGrad.addColorStop(0.55, 'rgba(3, 2, 2, 0.34)');
  bsGrad.addColorStop(1, 'rgba(3, 2, 2, 0)');
  bsCtx.fillStyle = bsGrad;
  bsCtx.beginPath();
  bsCtx.ellipse(260, 410, 228, 370, 0, 0, Math.PI * 2);
  bsCtx.fill();
  const shadowCrop = {
    imageData: bsCtx.getImageData(0, 0, 520, 820),
    w: 520,
    h: 820,
    pivotX: 260,
    pivotY: 410,
  };

  // Pack all sprite regions cleanly onto one atlas (perfectly top-down: no visible legs)
  const items = [
    { key: 'rump', ...rumpCrop },
    { key: 'torso', ...torsoCrop },
    { key: 'head', ...headCrop },
    { key: 'bodyShadow', ...shadowCrop },
  ];

  const atlasW = 1600;
  const gap = 4;
  let curX = gap;
  let curY = gap;
  let rowH = 0;
  const frames: Record<string, SheepAtlasFrame> = {};
  const placements: { imageData: ImageData; sx: number; sy: number }[] = [];

  for (const item of items) {
    if (curX + item.w + gap > atlasW) {
      curX = gap;
      curY += rowH + gap;
      rowH = 0;
    }
    placements.push({ imageData: item.imageData, sx: curX, sy: curY });
    frames[item.key] = {
      sx: curX,
      sy: curY,
      w: item.w,
      h: item.h,
      pivotX: item.pivotX,
      pivotY: item.pivotY,
    };
    curX += item.w + gap;
    if (item.h > rowH) rowH = item.h;
  }

  const atlasH = Math.max(1, curY + rowH + gap);
  const atlas = createCanvas(atlasW, atlasH);
  const atlasCtx = atlas.getContext('2d')!;
  for (const p of placements) {
    atlasCtx.putImageData(p.imageData, p.sx, p.sy);
  }

  return {
    sourceSize: size,
    atlas,
    rump: frames.rump,
    torso: frames.torso,
    head: frames.head,
    bodyShadow: frames.bodyShadow,
    legs: SHEEP_LEG_SPECS,
  };
}

export interface ComputedSheepLegTransform {
  legId: string;
  side: 'L' | 'R';
  root: Vec2;
  tip: Vec2;
  lift: number;
  isGrounded: boolean;
  strikePulse: number;
}

function rotateVec(x: number, y: number, rad: number): Vec2 {
  const c = Math.cos(rad);
  const s = Math.sin(rad);
  return { x: x * c - y * s, y: x * s + y * c };
}

function drawAtlasFrame(
  ctx: CanvasRenderingContext2D,
  atlas: HTMLCanvasElement,
  f: SheepAtlasFrame
) {
  ctx.drawImage(atlas, f.sx, f.sy, f.w, f.h, -f.pivotX, -f.pivotY, f.w, f.h);
}

/**
 * Renders the articulated NPC Sheep (painterly hooves peeking out during stride,
 * cast shadow, counter-swaying rear fleece, breathing mid-barrel wool, and
 * head/ears with grazing tuck and foraging yaw) onto ctx at (0, 0) in 1024-space facing +Y.
 */
export function renderSheepCreature(
  ctx: CanvasRenderingContext2D,
  rig: ExtractedSheepRig,
  legPoses: LegJointPose[],
  bodyPose: SheepBodyPose,
  options: {
    lightDir: Vec2;
    showRigOverlay: boolean;
    includeShadow?: boolean;
  }
): ComputedSheepLegTransform[] {
  const computed: ComputedSheepLegTransform[] = [];
  const includeShadow = options.includeShadow !== false;

  // 1. Cast ground shadow slightly offset by directional light
  if (includeShadow) {
    ctx.save();
    const sx = options.lightDir.x * bodyPose.elevationPx * 1.15;
    const sy = options.lightDir.y * bodyPose.elevationPx * 1.15 + bodyPose.surgePx;
    ctx.translate(sx, sy + 6);
    ctx.rotate(bodyPose.swayRad * 0.6);
    ctx.scale(bodyPose.fleeceSquashX * 0.98, bodyPose.fleeceSquashY * 0.98);
    drawAtlasFrame(ctx, rig.atlas, rig.bodyShadow);
    ctx.restore();
  }

  // 2. Compute concealed quadruped gait contact coordinates (no visible legs in top-down view)
  for (let i = 0; i < rig.legs.length; i++) {
    const leg = rig.legs[i];
    const pose = legPoses[i];
    const isRear = leg.index === 0;
    const sway = isRear ? bodyPose.rumpSwayRad : bodyPose.swayRad;
    const shiftX = isRear ? bodyPose.rumpShiftX : 0;

    const relX = leg.root.x - SHEEP_BODY_CENTER.x + shiftX;
    const relY = leg.root.y - SHEEP_BODY_CENTER.y;
    const rotRoot = rotateVec(relX, relY, sway);
    const worldRoot = {
      x: rotRoot.x * bodyPose.bobScale,
      y: rotRoot.y * bodyPose.bobScale + bodyPose.surgePx,
    };

    const dir = leg.side === 'L' ? -1 : 1;
    const strideAngle = dir * (-pose.coxaAngle * 1.4);
    const reach = (0.75 + 0.25 * Math.abs(pose.coxaAngle * 2.0)) * pose.reachScale;
    const tipLocal = rotateVec(dir * leg.boneLength * reach, 0, strideAngle);
    const worldTip = {
      x: worldRoot.x + tipLocal.x,
      y: worldRoot.y + tipLocal.y,
    };

    computed.push({
      legId: leg.id,
      side: leg.side,
      root: worldRoot,
      tip: worldTip,
      lift: pose.lift,
      isGrounded: pose.isGrounded,
      strikePulse: pose.strikePulse,
    });
  }

  // 3. Render Rear Haunches / Rump Fleece (counter-swaying pelvis)
  ctx.save();
  const rumpLocal = rotateVec(
    SHEEP_RUMP_CENTER.x - SHEEP_BODY_CENTER.x + bodyPose.rumpShiftX,
    SHEEP_RUMP_CENTER.y - SHEEP_BODY_CENTER.y,
    bodyPose.swayRad * 0.45
  );
  ctx.translate(
    rumpLocal.x * bodyPose.bobScale,
    rumpLocal.y * bodyPose.bobScale + bodyPose.surgePx
  );
  ctx.rotate(bodyPose.rumpSwayRad);
  ctx.scale(
    bodyPose.bobScale * bodyPose.fleeceSquashX,
    bodyPose.bobScale * bodyPose.fleeceSquashY
  );
  drawAtlasFrame(ctx, rig.atlas, rig.rump);
  ctx.restore();

  // 4. Render Main Mid-Barrel & Shoulder Fleece
  ctx.save();
  ctx.translate(0, bodyPose.surgePx);
  ctx.rotate(bodyPose.swayRad);
  ctx.scale(
    bodyPose.bobScale * bodyPose.fleeceSquashX,
    bodyPose.bobScale * bodyPose.fleeceSquashY
  );
  drawAtlasFrame(ctx, rig.atlas, rig.torso);
  ctx.restore();

  // 5. Render Sheep Head & Ears Layer (independent foraging yaw, nod & graze tuck)
  ctx.save();
  const neckOffset = rotateVec(
    SHEEP_HEAD_PIVOT.x - SHEEP_BODY_CENTER.x,
    SHEEP_HEAD_PIVOT.y - SHEEP_BODY_CENTER.y + bodyPose.headTuckPx,
    bodyPose.swayRad
  );
  ctx.translate(
    neckOffset.x * bodyPose.bobScale,
    neckOffset.y * bodyPose.bobScale + bodyPose.surgePx
  );
  ctx.rotate(bodyPose.swayRad * 0.75 + bodyPose.headYawRad);
  ctx.scale(bodyPose.bobScale, bodyPose.bobScale * bodyPose.headNodScale);
  drawAtlasFrame(ctx, rig.atlas, rig.head);
  ctx.restore();

  // 6. Optional Quadruped Skeletal Rig & Hoof Contact Overlay
  if (options.showRigOverlay) {
    ctx.save();
    // Draw quadruped spine from rump -> mid -> head pivot -> snout
    const spineRump = rotateVec(
      SHEEP_RUMP_CENTER.x - SHEEP_BODY_CENTER.x + bodyPose.rumpShiftX,
      SHEEP_RUMP_CENTER.y - SHEEP_BODY_CENTER.y,
      bodyPose.swayRad * 0.45
    );
    const spineHead = neckOffset;
    const snoutVec = rotateVec(0, 175 * bodyPose.headNodScale, bodyPose.swayRad * 0.75 + bodyPose.headYawRad);

    ctx.strokeStyle = 'rgba(230, 223, 209, 0.72)';
    ctx.lineWidth = 2.6;
    ctx.beginPath();
    ctx.moveTo(spineRump.x, spineRump.y + bodyPose.surgePx);
    ctx.lineTo(0, bodyPose.surgePx);
    ctx.lineTo(spineHead.x, spineHead.y + bodyPose.surgePx);
    ctx.lineTo(spineHead.x + snoutVec.x, spineHead.y + bodyPose.surgePx + snoutVec.y);
    ctx.stroke();

    // Spine joints
    for (const pt of [
      { x: spineRump.x, y: spineRump.y + bodyPose.surgePx },
      { x: 0, y: bodyPose.surgePx },
      { x: spineHead.x, y: spineHead.y + bodyPose.surgePx },
    ]) {
      ctx.fillStyle = '#c59b4c';
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, 6, 0, Math.PI * 2);
      ctx.fill();
    }

    // Quadruped limb bones & hoof contact rings
    for (const item of computed) {
      ctx.strokeStyle = item.isGrounded
        ? 'rgba(197, 155, 76, 0.85)'
        : 'rgba(218, 78, 72, 0.92)';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(item.root.x, item.root.y);
      ctx.lineTo(item.tip.x, item.tip.y);
      ctx.stroke();

      ctx.fillStyle = '#9e2a2b';
      ctx.beginPath();
      ctx.arc(item.root.x, item.root.y, 5.5, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = item.isGrounded
        ? 'rgba(197, 155, 76, 0.98)'
        : 'rgba(230, 223, 209, 0.45)';
      ctx.lineWidth = item.isGrounded ? 2.6 : 1.4;
      ctx.beginPath();
      ctx.arc(item.tip.x, item.tip.y, item.isGrounded ? 11 + item.strikePulse * 6 : 7, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.restore();
  }

  return computed;
}
